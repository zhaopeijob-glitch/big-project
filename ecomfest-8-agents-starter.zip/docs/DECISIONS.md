# 关键技术决策（ADR）
- 前端框架：Next.js — 选择原因：生态成熟、SSR/ISR 支持
- 甘特库：react-gantt（可替换评估）
- 后端：FastAPI — 选择原因：类型友好、性能可接受
- 存储：S3 兼容对象存储；本地开发使用 MinIO
