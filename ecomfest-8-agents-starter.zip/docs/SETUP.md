# 本地环境搭建
1. 需要安装：Node 20+, Python 3.11+, Docker, Docker Compose
2. 复制 `.env.example` 为 `.env` 并填写变量
3. 启动：`docker compose up --build`
4. 前端：http://localhost:3000  后端：http://localhost:8000/docs  MinIO 控制台：http://localhost:9001
