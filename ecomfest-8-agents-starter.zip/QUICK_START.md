# 最快路径（Quick Start）

1) 创建 GitHub 仓库并上传本模板。
2) 新建 Issue：Agent-1 需求梳理 → 填写 BRD/PRD。
3) 由助手协助完成 Agent-2 输出 ARCH/vars。
4) 进入 Agent-3：固化 OpenAPI/DB/Events/Auth。
5) 进入 Agent-3.5：输出 UI/UX 规范与线框。
6) 执行 Agent-4：在 VSCode 中用 CodeX 按契约生成代码。
7) 执行 Agent-5：跑 CI、补测试、修问题。
8) 执行 Agent-6：部署到测试→预发→生产，记录变更并配置回滚。

> 任一阶段不通过验收，不进入下一阶段。
