---
name: Agent-5 质量门禁
about: Lint/测试/安全/性能基线
---
## 输入
- PR/分支

## 产出
- [ ] /docs/qa/report.md

## 验收
- [ ] 静态检查通过
- [ ] 覆盖率 X%
- [ ] 无高危依赖
