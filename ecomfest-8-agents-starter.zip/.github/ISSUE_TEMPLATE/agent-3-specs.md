---
name: Agent-3 规格固化
about: OpenAPI/DB/Events/Auth 契约输出
---
## 输入
- /docs/ARCH.md, /spec/vars.yaml

## 产出
- [ ] /spec/api.yaml
- [ ] /spec/db/schema.sql
- [ ] /spec/authz.yaml
- [ ] /spec/events.yaml
- [ ] /spec/spec.yaml（聚合）

## 验收
- [ ] Linter 通过
- [ ] 字段含示例，无 TBD
