---
name: Agent-2 架构与框架
about: 技术选型/目录/变量注册表
---
## 输入
- /docs/BRD_PRD.md

## 产出
- [ ] /docs/ARCH.md
- [ ] /docs/DECISIONS.md
- [ ] /spec/vars.yaml
- [ ] /docs/SETUP.md

## 验收
- [ ] 分层清晰
- [ ] 变量覆盖环境/阈值/开关
