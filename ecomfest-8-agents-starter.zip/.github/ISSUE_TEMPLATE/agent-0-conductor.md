---
name: Agent-0 指挥官
about: 排期/状态流转与里程碑检查
---
## 输入
- 上一阶段验收结论：

## 检查项
- [ ] 规格是否存在且通过 linter（/spec/spec.yaml）
- [ ] 产物是否齐备（列出清单）

## 输出
- /docs/status.md 已更新
- 进入下一 Agent：
