---
name: Agent-6 部署与迭代
about: CI/CD、变更日志、回滚与复盘
---
## 输入
- main 分支构建产物

## 产出
- [ ] /docs/release/CHANGELOG.md
- [ ] /docs/runbook.md

## 验收
- [ ] 一键部署到测试/预发/生产
- [ ] 可灰度/可回滚
