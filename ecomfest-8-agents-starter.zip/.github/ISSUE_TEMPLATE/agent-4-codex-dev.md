---
name: Agent-4 CodeX 开发
about: 基于契约生成前后端脚手架与模块
---
## 输入
- /spec/spec.yaml, /design/*

## 产出
- [ ] /src/backend/*
- [ ] /src/frontend/*
- [ ] 本地可跑（docker compose）

## 验收
- [ ] 端点与模型与契约一致
- [ ] 关键页面路由存在
