---
name: Agent-1 需求梳理
about: 生成 BRD/PRD 文档
---
## 输入
- 业务目标/用户/场景：

## 产出
- [ ] /docs/BRD_PRD.md

## 验收
- [ ] 目标可量化
- [ ] 范围 In/Out 明确
- [ ] 风险与缓解策略
